def hello(name)
# by Mandy
	return "hello, " + name
end


def starts_with_consonant?(s)
# by Mandy
	if (s =~ /\A(?=[^aeiou])(?=[a-z])/i) == 0
		return true
	else 
		return false
	end	
end

def binary_multiple_of_4? (s)
# by Ray
	if (s =~ /\A^[0,1]*00$/) == 0
		return true
	else
		return false 
	end
end

#p hello("mandy")
#p starts_with_consonant?("mandy")
#p starts_with_consonant?("_aaaaa")

p binary_multiple_of_4? ("01010101")
p binary_multiple_of_4? ("01010100")
p binary_multiple_of_4? ("04010100")
