def sum arr
# by Ray
	sum = 0;
	arr.each do |x|
		sum += x
	end
	#{|i| sum+=i}
	return sum
end

def max_2_sum arr
# by Ray
	arr1 = arr.sort.reverse
	if arr1.length == 0
		return 0
	elsif arr1.length == 1
		return arr1[0]
	else
		return arr1[0] + arr1[1]
	end
end

def sum_to_n? arr,n
# by Lindsay
	arr.each do |x|
		arr.each do |y|
			if n==x+y 
				return true
			end	
		end
	end
	return false
end

#p sum([10,20,30])
#p sum([])
#p max_2_sum([10,20,30])
#p max_2_sum([10])
#p max_2_sum([])
p sum_to_n?([10,20,30],40	)	
p sum_to_n?([10,20,30],15	)
