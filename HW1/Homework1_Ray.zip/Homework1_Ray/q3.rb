class BookInStock
# by Ray and Lindsay
	attr_accessor	:isbn   #use the symbol
	attr_accessor	:price
	def initialize(isbn, price)
		raise ArgumentError, 'isbn is null' unless !isbn.empty?
		raise ArgumentError, 'price is is less than or equal to zero' unless price > 0
		@isbn = isbn
		@price = price
	end 

	def price_as_string
		sprintf "$%.2f", @price
		#return "$"+ @price.to_s "%.2f"
	end
end

book1 = BookInStock.new "hellypotter",12.2
p book1.isbn
p book1.price
p book1.price_as_string

#book2 = BookInStock.new "",12.89
#book3 = BookInStock.new "asdsa",-1